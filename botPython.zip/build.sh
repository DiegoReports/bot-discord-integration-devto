#!/bin/bash

zip -r "botPython.zip" * -x "botPython.zip"